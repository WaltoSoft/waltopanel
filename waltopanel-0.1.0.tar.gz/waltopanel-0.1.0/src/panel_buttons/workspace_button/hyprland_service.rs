use gtk::glib;
use serde_json::Value;
use std::cell::RefCell;
use std::collections::HashMap;
use std::env;
use std::io::{BufRead, BufReader, Read, Write};
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use std::rc::Rc;
use std::thread;
use std::time::Duration;

#[derive(Debug, Clone, PartialEq)]
pub struct WorkspaceInfo {
    pub id: i32,
    pub name: String,
    pub monitor: String,
    pub windows: i32,
    pub has_fullscreen: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub struct WindowInfo {
    pub address: String,
    pub workspace_id: i32,
    pub class: String,
    pub title: String,
    pub monitor: i32,
    pub pid: i32,
}

#[derive(Debug, Clone)]
pub struct WorkspaceState {
    pub workspaces: Vec<WorkspaceInfo>,
    pub windows: Vec<WindowInfo>,
    pub active_workspace_id: i32,
    pub active_window_address: Option<String>,
    pub _current_monitor: String,
}

type WorkspaceCallback = Box<dyn Fn(WorkspaceState)>;

struct MonitorSubscription {
    monitor_name: String,
    callback: WorkspaceCallback,
}

struct HyprlandServiceState {
    all_workspaces: Vec<WorkspaceInfo>,
    all_windows: Vec<WindowInfo>,
    active_workspace_id: i32,
    active_window_address: Option<String>,
    subscribers: Vec<MonitorSubscription>,
    _running: bool,
}

thread_local! {
    static HYPRLAND_SERVICE: RefCell<Option<Rc<RefCell<HyprlandServiceState>>>> = RefCell::new(None);
}

pub struct HyprlandService;

impl HyprlandService {
    /// Start the Hyprland service and return initial workspace state for a monitor
    pub fn start(monitor_name: String) -> WorkspaceState {
        HYPRLAND_SERVICE.with(|service| {
            // If service already running, just return current state for this monitor
            if let Some(state_ref) = service.borrow().as_ref() {
                let state = state_ref.borrow();
                return Self::filter_workspace_state_for_monitor(
                    &state.all_workspaces,
                    &state.all_windows,
                    state.active_workspace_id,
                    state.active_window_address.clone(),
                    &monitor_name,
                );
            }

            // First time initialization
            let all_workspaces = Self::query_workspaces().unwrap_or_default();
            let all_windows = Self::query_windows().unwrap_or_default();
            let active_workspace_id = Self::query_active_workspace().unwrap_or(1);
            let active_window_address = Self::query_active_window().unwrap_or(None);

            let service_state = Rc::new(RefCell::new(HyprlandServiceState {
                all_workspaces: all_workspaces.clone(),
                all_windows: all_windows.clone(),
                active_workspace_id,
                active_window_address: active_window_address.clone(),
                subscribers: Vec::new(),
                _running: true,
            }));

            *service.borrow_mut() = Some(service_state.clone());

            // Start event listener in a separate thread
            Self::start_event_listener();
            Self::start_dpms_watcher();

            // Return filtered state for this monitor
            Self::filter_workspace_state_for_monitor(
                &all_workspaces,
                &all_windows,
                active_workspace_id,
                active_window_address,
                &monitor_name,
            )
        })
    }

    pub fn _stop() {
        HYPRLAND_SERVICE.with(|service| {
            if let Some(state) = service.borrow().as_ref() {
                state.borrow_mut()._running = false;
            }
            *service.borrow_mut() = None;
        });
    }

    pub fn subscribe<F>(monitor_name: String, callback: F)
    where
        F: Fn(WorkspaceState) + 'static,
    {
        HYPRLAND_SERVICE.with(|service| {
            if let Some(state) = service.borrow().as_ref() {
                state.borrow_mut().subscribers.push(MonitorSubscription {
                    monitor_name,
                    callback: Box::new(callback),
                });
            }
        });
    }

    /// Switch to a workspace by ID
    pub fn switch_workspace(workspace_id: i32) {
        if let Err(e) = Self::send_command(&format!("dispatch workspace {}", workspace_id)) {
            eprintln!("Failed to switch workspace: {}", e);
        }
    }

    /// Focus a window by its address
    pub fn focus_window(window_address: &str) {
        if let Err(e) = Self::send_command(&format!("dispatch focuswindow address:{}", window_address)) {
            eprintln!("Failed to focus window: {}", e);
        }
    }

    /// Create a new workspace and switch to it, or switch to existing empty workspace
    pub fn create_new_workspace_on_monitor(monitor_name: &str) {
        // Check if this monitor already has an empty workspace
        if let Ok(workspaces) = Self::query_workspaces() {
            let empty_workspace = workspaces
                .iter()
                .find(|ws| ws.monitor == monitor_name && ws.windows == 0);

            if let Some(empty_ws) = empty_workspace {
                Self::switch_workspace(empty_ws.id);
                return;
            }
        }

        // No empty workspace on this monitor, create a new one
        // Find the next available workspace ID
        let workspaces = Self::query_workspaces().unwrap_or_default();
        let max_id = workspaces.iter().map(|ws| ws.id).max().unwrap_or(0);
        let new_workspace_id = max_id + 1;

        // First, focus this monitor to ensure the workspace is created on the correct monitor
        if let Err(e) = Self::send_command(&format!("dispatch focusmonitor {}", monitor_name)) {
            eprintln!("Failed to focus monitor: {}", e);
        }

        // Now switch to the new workspace ID (this will create it on the focused monitor)
        if let Err(e) = Self::send_command(&format!("dispatch workspace {}", new_workspace_id)) {
            eprintln!("Failed to create new workspace: {}", e);
        }
    }

    /// Move all workspaces from external monitors to the first internal (eDP-*) display.
    /// Intended to be called when switching a KVM switch away from this machine.
    pub fn move_all_to_laptop() {
        let monitors_json = match Self::send_command("j/monitors") {
            Ok(j) => j,
            Err(e) => { eprintln!("[HyprlandService] move_all_to_laptop: failed to query monitors: {}", e); return; }
        };
        let monitors: Value = match serde_json::from_str(&monitors_json) {
            Ok(v) => v,
            Err(e) => { eprintln!("[HyprlandService] move_all_to_laptop: failed to parse monitors: {}", e); return; }
        };
        let monitors_array = match monitors.as_array() {
            Some(a) => a,
            None => return,
        };
        let laptop = match monitors_array.iter().find_map(|m| {
            let name = m["name"].as_str()?;
            if name.starts_with("eDP") { Some(name.to_string()) } else { None }
        }) {
            Some(l) => l,
            None => { eprintln!("[HyprlandService] move_all_to_laptop: no eDP monitor found"); return; }
        };
        let laptop_only = vec![laptop.clone()];
        Self::move_orphaned_workspaces_to(&laptop, &laptop_only);
    }

    /// Move any workspaces assigned to a connector not in `active_connectors`
    /// to `target_monitor`. Uses the GDK-provided connector list rather than
    /// querying Hyprland's monitor list, because Hyprland's IPC can lag behind
    /// GDK when multiple monitors disconnect simultaneously.
    pub fn move_orphaned_workspaces_to(target_monitor: &str, active_connectors: &[String]) {
        let workspaces_json = match Self::send_command("j/workspaces") {
            Ok(r) => r,
            Err(e) => { eprintln!("[HyprlandService] Failed to query workspaces: {}", e); return; }
        };

        let workspaces: Value = match serde_json::from_str(&workspaces_json) {
            Ok(v) => v,
            Err(e) => { eprintln!("[HyprlandService] Failed to parse workspaces: {}", e); return; }
        };

        if let Some(ws_array) = workspaces.as_array() {
            for ws in ws_array {
                if let (Some(ws_id), Some(ws_monitor)) = (ws["id"].as_i64(), ws["monitor"].as_str()) {
                    if !active_connectors.contains(&ws_monitor.to_string()) {
                        let _ = Self::send_command(&format!(
                            "dispatch moveworkspacetomonitor {} {}",
                            ws_id, target_monitor
                        ));
                    }
                }
            }
        }
    }

    /// Get the socket path for Hyprland IPC
    fn get_socket_path() -> Result<PathBuf, String> {
        let runtime_dir = env::var("XDG_RUNTIME_DIR")
            .map_err(|_| "XDG_RUNTIME_DIR not set".to_string())?;

        let instance_sig = env::var("HYPRLAND_INSTANCE_SIGNATURE")
            .map_err(|_| "HYPRLAND_INSTANCE_SIGNATURE not set".to_string())?;

        Ok(PathBuf::from(runtime_dir)
            .join("hypr")
            .join(instance_sig)
            .join(".socket.sock"))
    }

    /// Get the event socket path for Hyprland IPC
    fn get_event_socket_path() -> Result<PathBuf, String> {
        let runtime_dir = env::var("XDG_RUNTIME_DIR")
            .map_err(|_| "XDG_RUNTIME_DIR not set".to_string())?;

        let instance_sig = env::var("HYPRLAND_INSTANCE_SIGNATURE")
            .map_err(|_| "HYPRLAND_INSTANCE_SIGNATURE not set".to_string())?;

        Ok(PathBuf::from(runtime_dir)
            .join("hypr")
            .join(instance_sig)
            .join(".socket2.sock"))
    }

    /// Send a command to Hyprland
    fn send_command(command: &str) -> Result<String, String> {
        let socket_path = Self::get_socket_path()?;

        let mut stream = UnixStream::connect(&socket_path)
            .map_err(|e| format!("Failed to connect to Hyprland socket: {}", e))?;

        stream
            .write_all(command.as_bytes())
            .map_err(|e| format!("Failed to write to socket: {}", e))?;

        let mut response = String::new();
        stream
            .read_to_string(&mut response)
            .map_err(|e| format!("Failed to read response: {}", e))?;

        Ok(response)
    }

    /// Query workspace information from Hyprland
    fn query_workspaces() -> Result<Vec<WorkspaceInfo>, String> {
        let response = Self::send_command("j/workspaces")?;
        let workspaces: Value = serde_json::from_str(&response)
            .map_err(|e| format!("Failed to parse JSON: {}. Response was: {}", e, response))?;

        let mut result = Vec::new();

        if let Some(ws_array) = workspaces.as_array() {
            for ws in ws_array {
                if let (Some(id), Some(name), Some(monitor), Some(windows)) = (
                    ws["id"].as_i64(),
                    ws["name"].as_str(),
                    ws["monitor"].as_str(),
                    ws["windows"].as_i64(),
                ) {
                    result.push(WorkspaceInfo {
                        id: id as i32,
                        name: name.to_string(),
                        monitor: monitor.to_string(),
                        windows: windows as i32,
                        has_fullscreen: ws["hasfullscreen"].as_bool().unwrap_or(false),
                    });
                }
            }
        }

        Ok(result)
    }

    /// Get the active workspace ID (globally focused)
    fn query_active_workspace() -> Result<i32, String> {
        let response = Self::send_command("j/activeworkspace")?;
        let workspace: Value = serde_json::from_str(&response)
            .map_err(|e| format!("Failed to parse JSON: {}", e))?;

        workspace["id"]
            .as_i64()
            .map(|id| id as i32)
            .ok_or_else(|| "Failed to get active workspace ID".to_string())
    }

    /// Query all windows from Hyprland
    fn query_windows() -> Result<Vec<WindowInfo>, String> {
        let response = Self::send_command("j/clients")?;
        let clients: Value = serde_json::from_str(&response)
            .map_err(|e| format!("Failed to parse clients JSON: {}. Response was: {}", e, response))?;

        let mut result = Vec::new();

        if let Some(clients_array) = clients.as_array() {
            for client in clients_array {
                if let (Some(address), Some(workspace_id), Some(class), Some(title)) = (
                    client["address"].as_str(),
                    client["workspace"]["id"].as_i64(),
                    client["class"].as_str(),
                    client["title"].as_str(),
                ) {
                    result.push(WindowInfo {
                        address: address.to_string(),
                        workspace_id: workspace_id as i32,
                        class: class.to_string(),
                        title: title.to_string(),
                        monitor: client["monitor"].as_i64().unwrap_or(0) as i32,
                        pid: client["pid"].as_i64().unwrap_or(0) as i32,
                    });
                }
            }
        }

        Ok(result)
    }

    /// Get the currently focused window address
    fn query_active_window() -> Result<Option<String>, String> {
        let response = Self::send_command("j/activewindow")?;
        let window: Value = serde_json::from_str(&response)
            .map_err(|e| format!("Failed to parse active window JSON: {}", e))?;

        // If there's no active window, Hyprland returns an empty object or null address
        if let Some(address) = window["address"].as_str() {
            if !address.is_empty() && address != "0x0" {
                return Ok(Some(address.to_string()));
            }
        }

        Ok(None)
    }

    /// Get the active workspace ID for a specific monitor
    fn query_active_workspace_for_monitor(monitor_name: &str) -> Result<i32, String> {
        let response = Self::send_command("j/monitors")?;
        let monitors: Value = serde_json::from_str(&response)
            .map_err(|e| format!("Failed to parse monitors JSON: {}", e))?;

        if let Some(monitors_array) = monitors.as_array() {
            for monitor in monitors_array {
                if let Some(name) = monitor["name"].as_str() {
                    if name == monitor_name {
                        if let Some(workspace_id) = monitor["activeWorkspace"]["id"].as_i64() {
                            return Ok(workspace_id as i32);
                        }
                    }
                }
            }
        }

        Err(format!("Could not find active workspace for monitor {}", monitor_name))
    }

    /// Filter workspace state for a specific monitor
    fn filter_workspace_state_for_monitor(
        all_workspaces: &[WorkspaceInfo],
        all_windows: &[WindowInfo],
        _global_active_workspace_id: i32,
        active_window_address: Option<String>,
        monitor_name: &str,
    ) -> WorkspaceState {
        // Filter workspaces for this monitor and apply visibility rules
        let monitor_workspaces = Self::filter_visible_workspaces(all_workspaces, monitor_name);

        // Get workspace IDs for this monitor
        let monitor_workspace_ids: Vec<i32> = monitor_workspaces.iter().map(|ws| ws.id).collect();

        // Filter windows to only those on this monitor's workspaces
        let monitor_windows: Vec<WindowInfo> = all_windows
            .iter()
            .filter(|w| monitor_workspace_ids.contains(&w.workspace_id))
            .cloned()
            .collect();

        // Get the active workspace for THIS monitor specifically
        let active_workspace_id = Self::query_active_workspace_for_monitor(monitor_name)
            .unwrap_or(_global_active_workspace_id);

        WorkspaceState {
            workspaces: monitor_workspaces,
            windows: monitor_windows,
            active_workspace_id,
            active_window_address,
            _current_monitor: monitor_name.to_string(),
        }
    }

    /// Filter workspaces according to the visibility rules:
    /// - Show workspaces with windows
    /// - Keep only one empty workspace per monitor
    fn filter_visible_workspaces(
        workspaces: &[WorkspaceInfo],
        monitor_name: &str,
    ) -> Vec<WorkspaceInfo> {
        let mut monitor_workspaces: Vec<WorkspaceInfo> = workspaces
            .iter()
            .filter(|ws| ws.monitor == monitor_name)
            .cloned()
            .collect();

        // Sort by ID
        monitor_workspaces.sort_by_key(|ws| ws.id);

        // Count empty workspaces
        let empty_workspaces: Vec<&WorkspaceInfo> = monitor_workspaces
            .iter()
            .filter(|ws| ws.windows == 0)
            .collect();

        // If there are multiple empty workspaces, keep only the first one
        if empty_workspaces.len() > 1 {
            let first_empty_id = empty_workspaces[0].id;
            monitor_workspaces.retain(|ws| ws.windows > 0 || ws.id == first_empty_id);
        }

        monitor_workspaces
    }

    /// Notify all subscribers with updated workspace states
    fn notify_subscribers() {
        HYPRLAND_SERVICE.with(|service| {
            if let Some(state_ref) = service.borrow().as_ref() {
                let state = state_ref.borrow();
                let all_workspaces = state.all_workspaces.clone();
                let all_windows = state.all_windows.clone();
                let active_workspace_id = state.active_workspace_id;
                let active_window_address = state.active_window_address.clone();

                // Notify each subscriber with their monitor-specific state
                for sub in &state.subscribers {
                    let monitor_state = Self::filter_workspace_state_for_monitor(
                        &all_workspaces,
                        &all_windows,
                        active_workspace_id,
                        active_window_address.clone(),
                        &sub.monitor_name,
                    );
                    (sub.callback)(monitor_state);
                }
            }
        });
    }

    /// Start listening to Hyprland events
    fn start_event_listener() {
        thread::spawn(move || {
            let event_socket_path = match Self::get_event_socket_path() {
                Ok(path) => path,
                Err(e) => {
                    eprintln!("Failed to get event socket path: {}", e);
                    return;
                }
            };

            let stream = match UnixStream::connect(&event_socket_path) {
                Ok(s) => s,
                Err(e) => {
                    eprintln!("Failed to connect to Hyprland event socket: {}", e);
                    return;
                }
            };

            let reader = BufReader::new(stream);

            for line in reader.lines() {
                if let Ok(event) = line {
                    // When Hyprland removes a monitor, immediately move orphaned workspaces
                    // in the background thread. GDK doesn't always fire items_changed for
                    // all monitor disconnections (e.g. DDC/CI keeps DP-2 "connected" in GDK).
                    if event.starts_with("monitorremoved>>") {
                        // At this point Hyprland has already removed the monitor from its
                        // internal list, so j/monitors will give us the authoritative set.
                        if let Ok(monitors_json) = Self::send_command("j/monitors") {
                            if let Ok(monitors_val) = serde_json::from_str::<serde_json::Value>(&monitors_json) {
                                let active: Vec<String> = monitors_val
                                    .as_array()
                                    .unwrap_or(&vec![])
                                    .iter()
                                    .filter_map(|m| m["name"].as_str().map(|s| s.to_string()))
                                    .collect();
                                if let Some(target) = active.first().cloned() {
                                    Self::move_orphaned_workspaces_to(&target, &active);
                                }
                            }
                        }
                    }

                    // Check if this is a workspace, window, or monitor-related event
                    if event.starts_with("workspace>>")
                        || event.starts_with("createworkspace>>")
                        || event.starts_with("destroyworkspace>>")
                        || event.starts_with("moveworkspace>>")
                        || event.starts_with("moveworkspacev2>>")
                        || event.starts_with("openwindow>>")
                        || event.starts_with("closewindow>>")
                        || event.starts_with("movewindow>>")
                        || event.starts_with("activewindow>>")
                        || event.starts_with("monitorremoved>>")
                        || event.starts_with("monitoradded>>")
                    {
                        // Schedule the state update on the main thread
                        glib::idle_add_once(move || {
                            // Update global workspace and window state
                            let all_workspaces = Self::query_workspaces().unwrap_or_default();
                            let all_windows = Self::query_windows().unwrap_or_default();
                            let active_workspace_id =
                                Self::query_active_workspace().unwrap_or(1);
                            let active_window_address = Self::query_active_window().unwrap_or(None);

                            HYPRLAND_SERVICE.with(|service| {
                                if let Some(state_ref) = service.borrow().as_ref() {
                                    let mut state = state_ref.borrow_mut();
                                    state.all_workspaces = all_workspaces;
                                    state.all_windows = all_windows;
                                    state.active_workspace_id = active_workspace_id;
                                    state.active_window_address = active_window_address;
                                }
                            });

                            // Notify all subscribers
                            Self::notify_subscribers();
                        });
                    }
                }
            }
        });
    }

    /// Poll monitor DPMS status every 2 seconds. When an external monitor transitions
    /// from DPMS-on to DPMS-off (e.g. KVM switch), move its workspaces to the first
    /// monitor that still has DPMS on.
    fn start_dpms_watcher() {
        thread::spawn(move || {
            // Give Hyprland a moment to settle before we start polling.
            thread::sleep(Duration::from_secs(3));

            let mut prev_dpms: HashMap<String, bool> = HashMap::new();

            loop {
                thread::sleep(Duration::from_secs(2));

                let monitors_json = match Self::send_command("j/monitors") {
                    Ok(j) => j,
                    Err(_) => continue,
                };

                let monitors: Value = match serde_json::from_str(&monitors_json) {
                    Ok(v) => v,
                    Err(_) => continue,
                };

                let monitors_array = match monitors.as_array() {
                    Some(a) => a.clone(),
                    None => continue,
                };

                // Collect monitors that currently have DPMS on.
                let dpms_on: Vec<String> = monitors_array.iter()
                    .filter_map(|m| {
                        let name = m["name"].as_str()?.to_string();
                        let dpms = m["dpmsStatus"].as_bool().unwrap_or(true);
                        if dpms { Some(name) } else { None }
                    })
                    .collect();

                for monitor in &monitors_array {
                    let name = match monitor["name"].as_str() {
                        Some(n) => n.to_string(),
                        None => continue,
                    };
                    let dpms = monitor["dpmsStatus"].as_bool().unwrap_or(true);
                    let was_on = *prev_dpms.get(&name).unwrap_or(&true);

                    if was_on && !dpms {
                        // This monitor just lost DPMS — KVM likely switched away.
                        eprintln!("[HyprlandService] DPMS off on {}, moving workspaces to {:?}", name, dpms_on.first());
                        if let Some(target) = dpms_on.first().cloned() {
                            Self::move_orphaned_workspaces_to(&target, &dpms_on);
                        }
                    }

                    prev_dpms.insert(name, dpms);
                }
            }
        });
    }
}
